#!/system/bin/sh
# انتظر 30 ثانية لضمان إقلاع النظام بالكامل
sleep 30

# تحسين سرعة استجابة اللمس والواجهة
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# تحسين أداء الذاكرة (بسيط وآمن)
echo "100" > /proc/sys/vm/swappiness
echo "0" > /proc/sys/vm/vfs_cache_pressure
