#!/system/bin/sh
# ننتظر دقيقة كاملة ليتخطى النظام مرحلة الحماية عند الإقلاع
sleep 60

# تنفيذ الأمر وتكراره للتأكيد
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# طريقة احتياطية في حال فشل الأولى
content insert --uri content://settings/global --bind name:s:window_animation_scale --bind value:s:0.5
